<?php
session_start();

// Restore session from cookies if session expired
if (!isset($_SESSION['user_id']) && isset($_COOKIE['user_id'])) {
    $_SESSION['user_id']      = $_COOKIE['user_id'];
    $_SESSION['user_name']    = $_COOKIE['user_name'] ?? '';
    $_SESSION['user_email']   = $_COOKIE['user_email'] ?? '';
    $_SESSION['user_role']    = $_COOKIE['user_role'] ?? '';
    $_SESSION['profile_image']= $_COOKIE['profile_image'] ?? '';
}

// Final check – if still no session or cookies, redirect to login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
