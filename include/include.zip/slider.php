<?php
$current_page = basename($_SERVER['PHP_SELF']);

if (!function_exists('isActive')) {
    function isActive($pages) {
        global $current_page;
        return in_array($current_page, (array)$pages) ? 'sa-nav__menu-item--active' : '';
    }
}

if (!function_exists('isOpen')) {
    function isOpen($pages) {
        global $current_page;
        return in_array($current_page, (array)$pages) ? 'sa-nav__menu-item--open' : '';
    }
}

if (!function_exists('activeLink')) {
    function activeLink($page) {
        global $current_page;
        return $current_page === $page ? 'sa-nav__link--active' : '';
    }
}
?>

<style>
    :root {
        --sidebar-bg: #1f2933;
        --sidebar-bg-2: #111827;
        --sidebar-card: rgba(255,255,255,.06);
        --sidebar-border: rgba(255,255,255,.09);
        --sidebar-text: #d1d5db;
        --sidebar-muted: #9ca3af;
        --sidebar-active: #facc15;
        --sidebar-active-soft: rgba(250, 204, 21, .14);
    }

    .sa-app__sidebar {
        background: var(--sidebar-bg);
    }

    .sa-sidebar {
        background: linear-gradient(180deg, #263238 0%, #111827 100%);
        color: #ffffff;
        border-right: 1px solid rgba(255,255,255,.06);
    }

    /* =========================
       Improved Brand Header
    ========================= */
    .sa-sidebar__header {
        height: 78px;
        display: flex;
        align-items: center;
        padding: 12px;
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
        border-bottom: 1px solid rgba(15, 23, 42, 0.08);
    }

    .sa-sidebar__brand {
        width: 100%;
        min-height: 54px;
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 8px 9px;
        box-shadow: 0 8px 22px rgba(15, 23, 42, 0.08);
        transition: all 0.18s ease;
    }

    .sa-sidebar__brand:hover {
        transform: translateY(-1px);
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.12);
    }

    .sa-sidebar__brand-logo {
        width: 42px;
        height: 42px;
        min-width: 42px;
        border-radius: 14px;
        background: #facc15;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        border: 1px solid rgba(17, 24, 39, 0.08);
    }

    .sa-sidebar__brand-logo img {
        width: 38px;
        height: 38px;
        object-fit: contain;
        background: #ffffff;
        border-radius: 12px;
        padding: 3px;
    }

    .sa-sidebar__brand-info {
        min-width: 0;
        flex: 1;
    }

    .sa-sidebar__brand-title {
        color: #111827;
        font-size: 14px;
        font-weight: 950;
        letter-spacing: 0.5px;
        line-height: 1.1;
    }

    .sa-sidebar__brand-subtitle {
        color: #6b7280;
        font-size: 11px;
        font-weight: 750;
        margin-top: 3px;
        line-height: 1.1;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .sa-sidebar__brand-badge {
        background: #dcfce7;
        color: #166534;
        border: 1px solid #bbf7d0;
        border-radius: 999px;
        padding: 4px 7px;
        font-size: 10px;
        font-weight: 900;
        text-transform: uppercase;
    }

    /* =========================
       Sidebar Body
    ========================= */
    .sa-sidebar__body {
        padding: 12px 9px;
        height: calc(100vh - 78px);
        overflow-y: auto;
    }

    .sa-sidebar__body::-webkit-scrollbar {
        width: 5px;
    }

    .sa-sidebar__body::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,.18);
        border-radius: 20px;
    }

    /* =========================
       Quick Actions
    ========================= */
    .sa-sidebar-quick {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 7px;
        margin: 2px 5px 12px;
    }

    .sa-sidebar-quick a {
        background: var(--sidebar-card);
        border: 1px solid var(--sidebar-border);
        color: #ffffff;
        text-decoration: none;
        border-radius: 12px;
        padding: 9px 8px;
        font-size: 12px;
        font-weight: 850;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        transition: all .18s ease;
    }

    .sa-sidebar-quick a:hover {
        background: var(--sidebar-active);
        color: #111827;
        border-color: var(--sidebar-active);
    }

    /* =========================
       Sidebar Search
    ========================= */
    .sa-sidebar-search {
        margin: 0 5px 12px;
        position: relative;
    }

    .sa-sidebar-search input {
        width: 100%;
        border: 1px solid var(--sidebar-border);
        background: rgba(255,255,255,.06);
        color: #ffffff;
        border-radius: 12px;
        height: 38px;
        padding: 0 12px 0 34px;
        font-size: 13px;
        font-weight: 700;
        outline: none;
    }

    .sa-sidebar-search input::placeholder {
        color: #9ca3af;
    }

    .sa-sidebar-search span {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #9ca3af;
        font-size: 14px;
    }

    /* =========================
       Navigation
    ========================= */
    .sa-nav__section-title {
        color: var(--sidebar-muted);
        font-size: 11px;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: .6px;
        padding: 13px 12px 8px;
    }

    .sa-nav__menu {
        padding-left: 0;
        list-style: none;
        margin: 0;
    }

    .sa-nav__menu-item {
        margin-bottom: 3px;
    }

    .sa-nav__link {
        color: var(--sidebar-text) !important;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 11px;
        padding: 10px 12px;
        border-radius: 11px;
        font-size: 13px;
        font-weight: 750;
        transition: all .16s ease;
        position: relative;
    }

    .sa-nav__link:hover {
        background: rgba(255,255,255,.08);
        color: #ffffff !important;
    }

    .sa-nav__menu-item--active > .sa-nav__link,
    .sa-nav__link--active {
        background: var(--sidebar-active) !important;
        color: #111827 !important;
        font-weight: 950;
        box-shadow: 0 8px 18px rgba(250, 204, 21, .22);
    }

    .sa-nav__menu-item--active > .sa-nav__link::before,
    .sa-nav__link--active::before {
        content: "";
        position: absolute;
        left: -7px;
        top: 9px;
        bottom: 9px;
        width: 3px;
        background: var(--sidebar-active);
        border-radius: 10px;
    }

    .sa-nav__icon {
        width: 19px;
        min-width: 19px;
        height: 19px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: inherit;
        opacity: .95;
    }

    .sa-nav__icon svg {
        width: 18px;
        height: 18px;
        fill: currentColor;
    }

    .sa-nav__title {
        flex: 1;
        line-height: 1.25;
    }

    .sa-nav__arrow {
        width: 14px;
        height: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        opacity: .75;
        transition: transform .18s ease;
        font-size: 17px;
        font-weight: 900;
    }

    .sa-nav__menu-item--open > .sa-nav__link .sa-nav__arrow {
        transform: rotate(-90deg);
    }

    .sa-nav__menu--sub {
        display: none;
        padding: 5px 0 7px 31px;
    }

    .sa-nav__menu-item--open > .sa-nav__menu--sub {
        display: block;
    }

    .sa-nav__menu--sub .sa-nav__menu-item {
        margin-bottom: 2px;
    }

    .sa-nav__menu--sub .sa-nav__link {
        padding: 8px 10px;
        font-size: 12.5px;
        font-weight: 700;
        color: #cbd5e1 !important;
        border-radius: 9px;
    }

    .sa-nav__menu--sub .sa-nav__link:hover {
        background: rgba(255,255,255,.07);
        color: #ffffff !important;
    }

    .sa-nav__menu--sub .sa-nav__link--active {
        background: var(--sidebar-active-soft) !important;
        color: var(--sidebar-active) !important;
        font-weight: 950;
        box-shadow: none;
    }

    .sa-sidebar-divider {
        height: 1px;
        background: rgba(255,255,255,.09);
        margin: 11px 10px;
    }

    .sa-sidebar-footer-note {
        margin: 12px 5px 6px;
        padding: 12px 13px;
        color: #cbd5e1;
        font-size: 11px;
        line-height: 1.5;
        border-radius: 14px;
        background: rgba(255,255,255,.06);
        border: 1px solid rgba(255,255,255,.08);
    }

    .sa-sidebar-footer-note strong {
        color: #ffffff;
        font-size: 12px;
    }

    .sa-sidebar-footer-note span {
        color: #9ca3af;
    }

    .sa-nav__menu-item.is-hidden-by-search {
        display: none !important;
    }

    @media (max-width: 767px) {
        .sa-sidebar__header {
            height: 70px;
            padding: 10px;
        }

        .sa-sidebar__brand {
            min-height: 50px;
            border-radius: 14px;
        }

        .sa-sidebar__brand-logo {
            width: 38px;
            height: 38px;
            min-width: 38px;
            border-radius: 12px;
        }

        .sa-sidebar__brand-logo img {
            width: 34px;
            height: 34px;
        }

        .sa-sidebar__brand-title {
            font-size: 13px;
        }

        .sa-sidebar__brand-subtitle {
            font-size: 10px;
        }

        .sa-sidebar__body {
            height: calc(100vh - 70px);
            padding: 10px 8px;
        }

        .sa-nav__link {
            padding: 12px 13px;
            font-size: 14px;
        }

        .sa-nav__menu--sub .sa-nav__link {
            font-size: 13.5px;
            padding: 10px;
        }

        .sa-sidebar-quick {
            grid-template-columns: 1fr;
        }
    }
    .demo-header-4 {
    height: 76px;
    padding: 12px;
    background: linear-gradient(135deg, #111827 0%, #1f2937 55%, #263238 100%);
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.demo-brand-4 {
    width: 100%;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 8px 10px;
    background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 15px;
    text-decoration: none;
    box-shadow: 0 10px 24px rgba(0, 0, 0, 0.24);
    backdrop-filter: blur(8px);
    transition: all 0.18s ease;
}

.demo-brand-4:hover {
    background: rgba(255, 255, 255, 0.10);
    border-color: rgba(250, 204, 21, 0.45);
    transform: translateY(-1px);
}

.demo-brand-4-logo-wrap {
    flex: 1;
    min-width: 0;
    height: 36px;
    display: flex;
    align-items: center;
    background: #2f3845;
    border-radius: 11px;
    padding: 5px 8px;
}

.demo-brand-4-logo-wrap img {
    width: 142px;
    max-width: 100%;
    height: auto;
    object-fit: contain;
    display: block;
}

.demo-brand-4-meta {
    min-width: 50px;
    height: 36px;
    border-left: 1px solid rgba(255, 255, 255, 0.16);
    padding-left: 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.demo-brand-4-meta span {
    color: #facc15;
    font-size: 10px;
    font-weight: 900;
    line-height: 1;
    letter-spacing: 0.4px;
}

.demo-brand-4-meta strong {
    color: #ffffff;
    font-size: 12px;
    font-weight: 950;
    margin-top: 3px;
    line-height: 1;
}

@media (max-width: 767px) {
    .demo-header-4 {
        height: 70px;
        padding: 10px;
    }

    .demo-brand-4 {
        height: 50px;
        border-radius: 14px;
    }

    .demo-brand-4-logo-wrap {
        height: 34px;
        padding: 5px 7px;
    }

    .demo-brand-4-logo-wrap img {
        width: 132px;
    }

    .demo-brand-4-meta {
        height: 34px;
        min-width: 46px;
    }
}
</style>

<!-- sa-app__sidebar -->
<div class="sa-app__sidebar">
    <div class="sa-sidebar">

      <!-- Sidebar Header Demo 2 -->
<!-- Sidebar Header Demo 4 - Dark Background -->
<div class="sa-sidebar__header demo-header-4">
    <a class="demo-brand-4" href="dashboard.php">
        <div class="demo-brand-4-logo-wrap">
            <img src="https://app.mysathee.com/uploads/SATHEE.png" alt="SATHEE Logo">
        </div>

        <div class="demo-brand-4-meta">
            <span>CRM</span>
            <strong>Admin</strong>
        </div>
    </a>
</div>
        <!-- Sidebar Body -->
        <div class="sa-sidebar__body" data-simplebar="">
            <!-- Sidebar Search -->
            <div class="sa-sidebar-search">
                <span>🔎</span>
                <input type="text" id="sidebarMenuSearch" placeholder="Search menu...">
            </div>

            <ul class="sa-nav sa-nav--sidebar" data-sa-collapse="">
                <li class="sa-nav__section">
                    <div class="sa-nav__section-title">
                        <span>Application</span>
                    </div>

                    <ul class="sa-nav__menu sa-nav__menu--root" id="sidebarRootMenu">

                        <!-- Dashboard -->
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isActive('dashboard.php') ?>">
                            <a href="dashboard.php" class="sa-nav__link <?= activeLink('dashboard.php') ?>">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>
                                </span>
                                <span class="sa-nav__title">Dashboard</span>
                            </a>
                        </li>

                        <!-- Pending Orders -->
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isActive('pending_order_list.php') ?>">
                            <a href="pending_order_list.php" class="sa-nav__link <?= activeLink('pending_order_list.php') ?>">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M7 18c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.6-1.35 2.45C4.52 15.37 5.48 17 7 17h12v-2H7l1.1-2h7.45c.75 0 1.41-.41 1.75-1.03L21.7 4H5.21l-.94-2H1zm16 16c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                                </span>
                                <span class="sa-nav__title">Orders Pending</span>
                            </a>
                        </li>

                        <!-- Orders -->
                        <?php $ordersPages = ['order_list.php', 'add_order.php', 'view_order.php', 'edit_order.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($ordersPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14l4-4h12c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 8H7V9h10v2zm0-3H7V6h10v2z"/></svg>
                                </span>
                                <span class="sa-nav__title">Orders</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="order_list.php" class="sa-nav__link <?= activeLink('order_list.php') ?>">
                                        <span class="sa-nav__title">Orders List</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="add_order.php" class="sa-nav__link <?= activeLink('add_order.php') ?>">
                                        <span class="sa-nav__title">Add Order</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <!-- Catalog -->
                        <?php $catalogPages = ['product_list.php', 'add_product.php', 'edit_product.php', 'view_product.php', 'add_inventory.php', 'inventory_list.php', 'edit_inventory.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($catalogPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M20 6h-8l-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2z"/></svg>
                                </span>
                                <span class="sa-nav__title">Catalog</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="product_list.php" class="sa-nav__link <?= activeLink('product_list.php') ?>">
                                        <span class="sa-nav__title">Products List</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="add_product.php" class="sa-nav__link <?= activeLink('add_product.php') ?>">
                                        <span class="sa-nav__title">Add Product</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="add_inventory.php" class="sa-nav__link <?= activeLink('add_inventory.php') ?>">
                                        <span class="sa-nav__title">Add Inventory</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="inventory_list.php" class="sa-nav__link <?= activeLink('inventory_list.php') ?>">
                                        <span class="sa-nav__title">Inventory List</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <!-- Users -->
                        <?php $userPages = ['user_list.php', 'add_user.php', 'edit_user.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($userPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M12 12c2.7 0 5-2.3 5-5s-2.3-5-5-5-5 2.3-5 5 2.3 5 5 5zm0 2c-3.3 0-10 1.7-10 5v3h20v-3c0-3.3-6.7-5-10-5z"/></svg>
                                </span>
                                <span class="sa-nav__title">Users</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="user_list.php" class="sa-nav__link <?= activeLink('user_list.php') ?>">
                                        <span class="sa-nav__title">User List</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="add_user.php" class="sa-nav__link <?= activeLink('add_user.php') ?>">
                                        <span class="sa-nav__title">Add User</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <!-- Vendor -->
                        <?php $vendorPages = ['vendor_list.php', 'vendor_add.php', 'vendor_edit.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($vendorPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M16 11c1.7 0 3-1.3 3-3s-1.3-3-3-3-3 1.3-3 3 1.3 3 3 3zM8 11c1.7 0 3-1.3 3-3S9.7 5 8 5 5 6.3 5 8s1.3 3 3 3zm0 2c-2.3 0-7 1.2-7 3.5V19h14v-2.5C15 14.2 10.3 13 8 13zm8 0c-.3 0-.7 0-1.1.1 1.2.9 2.1 2 2.1 3.4V19h6v-2.5c0-2.3-4.7-3.5-7-3.5z"/></svg>
                                </span>
                                <span class="sa-nav__title">Vendor</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="vendor_list.php" class="sa-nav__link <?= activeLink('vendor_list.php') ?>">
                                        <span class="sa-nav__title">Vendor List</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="vendor_add.php" class="sa-nav__link <?= activeLink('vendor_add.php') ?>">
                                        <span class="sa-nav__title">Add Vendor</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <!-- Material -->
                        <?php $materialPages = ['raw_material_manage.php', 'raw_material_purchase_list.php', 'raw_material_purchase_add.php', 'raw_material_stock_report.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($materialPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M20 8h-3V4H7v4H4c-1.1 0-2 .9-2 2v8h20v-8c0-1.1-.9-2-2-2zM9 6h6v2H9V6zm13 14H2v2h20v-2z"/></svg>
                                </span>
                                <span class="sa-nav__title">Material</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="raw_material_manage.php" class="sa-nav__link <?= activeLink('raw_material_manage.php') ?>">
                                        <span class="sa-nav__title">Material Manage</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="raw_material_purchase_list.php" class="sa-nav__link <?= activeLink('raw_material_purchase_list.php') ?>">
                                        <span class="sa-nav__title">Material Purchase</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="raw_material_stock_report.php" class="sa-nav__link <?= activeLink('raw_material_stock_report.php') ?>">
                                        <span class="sa-nav__title">Material Stock Report</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <!-- Batch -->
                        <?php $batchPages = ['batch_list.php', 'batch_add.php', 'batch_view.php', 'batch_edit.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($batchPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M21 16V8l-9-5-9 5v8l9 5 9-5zM12 5.3L18 8.6l-6 3.3-6-3.3 6-3.3zM5 10.3l6 3.3v4.9l-6-3.3v-4.9zm8 8.2v-4.9l6-3.3v4.9l-6 3.3z"/></svg>
                                </span>
                                <span class="sa-nav__title">Batch</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="batch_list.php" class="sa-nav__link <?= activeLink('batch_list.php') ?>">
                                        <span class="sa-nav__title">Batch List</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="batch_add.php" class="sa-nav__link <?= activeLink('batch_add.php') ?>">
                                        <span class="sa-nav__title">Create Batch</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <!-- Distributor -->
                        <?php $distributorPages = ['distributor_list.php', 'distributor_add.php', 'distributor_edit.php', 'purchase_requests.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($distributorPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M12 12c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm0 2c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4z"/></svg>
                                </span>
                                <span class="sa-nav__title">Distributor</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="distributor_list.php" class="sa-nav__link <?= activeLink('distributor_list.php') ?>">
                                        <span class="sa-nav__title">Distributor List</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="purchase_requests.php" class="sa-nav__link <?= activeLink('purchase_requests.php') ?>">
                                        <span class="sa-nav__title">Purchase Requests</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="distributor_add.php" class="sa-nav__link <?= activeLink('distributor_add.php') ?>">
                                        <span class="sa-nav__title">Add Distributor</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="time_manage.php" class="sa-nav__link <?= activeLink('time_manage.php') ?>">
                                        <span class="sa-nav__title">Order Time Management</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <div class="sa-sidebar-divider"></div>

                        <!-- Reports -->
                        <?php $reportPages = ['report_distributor_performance.php', 'product_report.php']; ?>
                        <li class="sa-nav__menu-item sa-nav__menu-item--has-icon <?= isOpen($reportPages) ?>" data-sa-collapse-item="">
                            <a href="#" class="sa-nav__link" data-sa-collapse-trigger="">
                                <span class="sa-nav__icon">
                                    <svg viewBox="0 0 24 24"><path d="M3 3v18h18v-2H5V3H3zm4 12h3V8H7v7zm5 0h3V5h-3v10zm5 0h3v-4h-3v4z"/></svg>
                                </span>
                                <span class="sa-nav__title">Reports</span>
                                <span class="sa-nav__arrow">‹</span>
                            </a>

                            <ul class="sa-nav__menu sa-nav__menu--sub" data-sa-collapse-content="">
                                <li class="sa-nav__menu-item">
                                    <a href="report_distributor_performance.php" class="sa-nav__link <?= activeLink('report_distributor_performance.php') ?>">
                                        <span class="sa-nav__title">Distributor Performance</span>
                                    </a>
                                </li>
                                 <li class="sa-nav__menu-item">
                                    <a href="distributor_report.php" class="sa-nav__link <?= activeLink('distributor_report.php') ?>">
                                        <span class="sa-nav__title">Distributor Sale & Income Report</span>
                                    </a>
                                </li>
                                <li class="sa-nav__menu-item">
                                    <a href="product_report.php" class="sa-nav__link <?= activeLink('product_report.php') ?>">
                                        <span class="sa-nav__title">Product Report</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </li>
            </ul>

            <div class="sa-sidebar-footer-note">
                <strong>SATHEE Admin Panel</strong><br>
                <span>CRM Dashboard · Inventory · Orders</span>
            </div>
        </div>
    </div>

    <div class="sa-app__sidebar-shadow"></div>
    <div class="sa-app__sidebar-backdrop" data-sa-close-sidebar=""></div>
</div>
<!-- sa-app__sidebar / end -->

<script>
document.addEventListener('DOMContentLoaded', function () {
    const collapseTriggers = document.querySelectorAll('[data-sa-collapse-trigger]');
    const searchInput = document.getElementById('sidebarMenuSearch');
    const rootMenu = document.getElementById('sidebarRootMenu');

    /*
      Force all sidebar dropdowns closed on page load.
      This fixes the issue where all menus expand automatically.
    */
    document.querySelectorAll('[data-sa-collapse-item]').forEach(function (item) {
        item.classList.remove('sa-nav__menu-item--open');
    });

    collapseTriggers.forEach(function (trigger) {
        trigger.addEventListener('click', function (e) {
            e.preventDefault();

            const parent = this.closest('[data-sa-collapse-item]');
            if (!parent) return;

            const parentRoot = parent.parentElement;
            const alreadyOpen = parent.classList.contains('sa-nav__menu-item--open');

            /*
              Close all other menus first
            */
            if (parentRoot) {
                parentRoot.querySelectorAll('[data-sa-collapse-item]').forEach(function (item) {
                    item.classList.remove('sa-nav__menu-item--open');
                });
            }

            /*
              If clicked menu was already open, keep it closed.
              If it was closed, open it.
            */
            if (!alreadyOpen) {
                parent.classList.add('sa-nav__menu-item--open');
            }
        });
    });

    if (searchInput && rootMenu) {
        searchInput.addEventListener('input', function () {
            const query = this.value.trim().toLowerCase();
            const menuItems = rootMenu.querySelectorAll(':scope > .sa-nav__menu-item');

            menuItems.forEach(function (item) {
                const text = item.textContent.toLowerCase();

                if (!query) {
                    item.classList.remove('is-hidden-by-search');
                    item.classList.remove('sa-nav__menu-item--open');
                    return;
                }

                if (text.includes(query)) {
                    item.classList.remove('is-hidden-by-search');

                    if (item.querySelector('.sa-nav__menu--sub')) {
                        item.classList.add('sa-nav__menu-item--open');
                    }
                } else {
                    item.classList.add('is-hidden-by-search');
                }
            });
        });
    }
});
</script>